# Roadmap

## Phase 1
Workspace, users, roles, permissions, dynamic entities, module registry, theme registry, template registry.

## Phase 2
Studio: page builder, form builder, field editor, dashboard builder, theme editor, permission editor.

## Phase 3
Runtime: dynamic renderer, navigation, state persistence, global search.

## Phase 4
Automation: triggers, conditions, actions, notifications, approvals.

## Phase 5
Commercialization: template marketplace, white-label, billing, public deployment.
