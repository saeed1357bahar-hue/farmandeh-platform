# Farmandeh Platform v0.1

Metadata-driven, multi-tenant platform.

Core rule:
- Stable kernel
- Dynamic modules/pages/forms/data/workflows/themes
- Ordinary customization without source-code edits
- Multi-user from day one
